# encoding: utf-8
# module _cython_0_22_1
# from /usr/local/lib/python2.7/site-packages/gevent/core.so
# by generator 1.136
# no doc
# no imports

# no functions
# classes

class generator(object):
    # no doc
    def close(self, *args, **kwargs): # real signature unknown
        pass

    def next(self): # real signature unknown; restored from __doc__
        """ x.next() -> the next value, or raise StopIteration """
        pass

    def send(self, *args, **kwargs): # real signature unknown
        pass

    def throw(self, *args, **kwargs): # real signature unknown
        pass

    def __getattribute__(self, name): # real signature unknown; restored from __doc__
        """ x.__getattribute__('name') <==> x.name """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __iter__(self): # real signature unknown; restored from __doc__
        """ x.__iter__() <==> iter(x) """
        pass

    gi_running = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    __qualname__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """qualified name of the generator"""


    __name__ = 'generator'


